class Prueba3 {
	public static void main(String parametros[]) {
		System.out.println("parametros");
	}
}
