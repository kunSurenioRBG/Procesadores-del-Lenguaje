class Prueba12 {
	public static void main(String argv[]) {
		System.out.println  ( "\\  Uno  \n  Dos  \n  \\" + "\\+\\" + "\\\\" + ""   );
	}
}
