class Prueba13_rmj {
	public static void main(String argv[]) {
		     
		 
		System.out.println("123=100*1+10*2+3");
	}
}
