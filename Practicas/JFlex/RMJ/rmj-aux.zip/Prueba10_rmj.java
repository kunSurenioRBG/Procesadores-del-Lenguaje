class Prueba10_rmj {
	public static void main(String argv[]) {
		System.out.println("\"Uno\"  \"Dos\"");
	}
}
