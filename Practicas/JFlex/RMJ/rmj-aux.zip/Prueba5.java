class Prueba5 {
	public static void main(String argv[]) {
		String unoDosTres = "Uno Dos Tres";
		System.out.println(unoDosTres);
	}
}
