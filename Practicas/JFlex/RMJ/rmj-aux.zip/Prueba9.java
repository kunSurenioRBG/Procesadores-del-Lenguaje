class Prueba9 {
	public static void main(String argv[]) {
		String var1 = "Uno"+"Dos";
		System.out.println(var1+"Tres");
		String var2 = var1 + "Tres"+ var1 + "Cuatro";
		System.out.println(var1+var2);
	}
}
