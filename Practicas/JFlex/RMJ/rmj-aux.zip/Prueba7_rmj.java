class Prueba7_rmj {
	public static void main(String argv[]) {
		 
		 
		System.out.println("Uno+Dos+Tres+Cuatro+Cinco");
	}
}
