class Prueba6 {
	public static void main(String argv[]) {
		String _ = "Uno";
		System.out.println(_);
	}
}
