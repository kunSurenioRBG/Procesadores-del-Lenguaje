class Prueba14_rmj {
	public static void main(String argv[]) {
		 
	    System.out.println("Uno\n");		   
		 	   
        System.out.println("Uno\nDos;");		   
               
        System.out.println("Uno\nDos;\"Tres\"");		   
	}
}
