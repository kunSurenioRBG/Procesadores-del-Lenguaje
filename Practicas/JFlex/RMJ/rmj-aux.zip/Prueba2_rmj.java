class Prueba2_rmj {
	public static void main(String argv[]) {
		System.out.print("UnoDosTresCuatro");
	}
}
