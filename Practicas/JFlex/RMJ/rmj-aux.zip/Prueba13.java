class Prueba13 {
	public static void main(String argv[]) {
		String v1="1"; String v2="2"; String v3="3";
		String numero=v1+v2+v3+"="+"100*"+v1+"+10*"+v2+"+"+v3;
		System.out.println(numero);
	}
}
